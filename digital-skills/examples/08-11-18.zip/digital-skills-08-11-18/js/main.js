$(document).ready(function(){
  // Toggle the open-nav when the hamburger or cross is clicked
  $(".close, .hamburger").click(function(e){
   e.preventDefault();
   $(".main-nav").toggleClass('open-nav');
  });

  // Close the nav if a nav link is clicked
  // Note that the "li > a" is jQuery's syntax for "a is a descendent of li"
  $(".main-nav > li > a").click(function(e){
    e.preventDefault();
    $(".main-nav").removeClass('open-nav');
  });
});
