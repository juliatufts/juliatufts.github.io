I've split up the CSS into style.css and hamburger.css, so you need to only look at hamburger.css to see what styles are being used for the hamburger menu.

The smooth scroll library used can be found here: https://github.com/cferdinandi/smooth-scroll
