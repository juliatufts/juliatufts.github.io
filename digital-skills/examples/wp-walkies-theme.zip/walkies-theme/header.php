<!DOCTYPE html>
<html <?php language_attributes(); ?>>
  <head>
    <meta charset="<?php bloginfo( 'charset' ); ?>"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title><?php bloginfo( 'name' ); ?></title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Kavoon|Lora:400,400i,700,700i" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css"integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">

    <!-- My CSS -->
    <link rel="stylesheet" href="<?php echo get_stylesheet_uri(); ?>">
  </head>

  <body>
    <!-- Navigation -->
    <nav>
      <ul>
          <li><a href="index.html">Home</a></li>
          <li><a href="about.html">About</a></li>
          <li><a href="blog.html">Blog</a></li>
      </ul>
    </nav>