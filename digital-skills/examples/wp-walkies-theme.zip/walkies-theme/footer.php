

    <!-- Footer -->
    <section class="social">
      <ul>
        <li> <a href="https://www.instagram.com/"><i class="fab fa-instagram"></i></a></li>
        <li> <a href="https://www.facebook.com/"><i class="fab fa-facebook-square"></i></a></li>
        <li> <a href="https://twitter.com/"><i class="fab fa-twitter-square"></i></a></li>
      </ul>
    </section>

    <footer>
      <div class="wrapper">
        <h2>Contact</h2>
        <p>E-mail us at <a href="mailto:info@walkies.com">info@walkies.com</a></p>
        <p>Logo by Maxim Kulikov from the Noun Project</p>
      </div>
    </footer>
  </body>
</html>