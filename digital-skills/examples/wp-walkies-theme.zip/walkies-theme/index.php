
<?php get_header(); ?>
<!--     <header>
      <div class="wrapper">
        <h1>Walkies!</h1>
        <h2>An app for dog lovers</h2>
        <svg class="logo" alt="Smiling dog face" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" x="0px" y="0px" viewBox="0 0 100 125" style="enable-background:new 0 0 100 100;" xml:space="preserve"><g><circle cx="32.032" cy="12.243" r="7.243"/><circle cx="72.867" cy="12.243" r="7.243"/><path d="M20.716,47.424c-1.104,0-2,0.896-2,2c0,9.171,7.466,16.632,16.643,16.632c1.093,0,2.168-0.112,3.222-0.32V83.57   c0,6.303,5.128,11.43,11.431,11.43c6.309,0,11.44-5.127,11.44-11.43V65.729c1.058,0.213,2.137,0.328,3.231,0.328   c9.165,0,16.622-7.457,16.622-16.623c0-1.104-0.896-2-2-2s-2,0.896-2,2c0,6.96-5.662,12.623-12.622,12.623   c-1.554,0-3.068-0.285-4.537-0.859c-0.288-0.106-0.566-0.23-0.855-0.367c-3.582-1.663-6.19-4.973-6.988-8.897   c-0.137-0.601-0.219-1.244-0.243-1.911c-0.006-0.146-0.028-0.286-0.063-0.421c0.005-0.058,0.018-0.115,0.018-0.174v-7.086h0.074   c0,0,8.439-3.798,8.439-8.439v-1.508c0-3.812-3.09-6.902-6.902-6.902h-7.221c-3.812,0-6.902,3.09-6.902,6.902V33.9   c0,4.642,8.439,8.439,8.439,8.439h0.073v7.086c0,0.065,0.013,0.126,0.019,0.19c-0.032,0.126-0.053,0.258-0.059,0.393   c-0.222,5.015-3.404,9.417-8.113,11.218c-0.362,0.14-0.731,0.261-1.104,0.366H38.58v0.041c-1.043,0.276-2.12,0.423-3.222,0.423   c-6.971,0-12.643-5.667-12.643-12.632C22.716,48.319,21.82,47.424,20.716,47.424z M48.014,60.212v20.215c0,1.104,0.896,2,2,2   s2-0.896,2-2V60.164c1.488,1.753,3.326,3.205,5.438,4.212V83.57c0,4.097-3.338,7.43-7.44,7.43c-4.098,0-7.431-3.333-7.431-7.43   V64.4C44.695,63.38,46.535,61.945,48.014,60.212z"/></g>
        </svg>
      </div>
    </header> -->
    
    
    <h1>BLOG PAGE</h1>
     <section>
      <div class="wrapper">
      <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
         <div class="blog-post">
          <h2><?php the_title(); ?></h2>
          <?php the_content(); ?>
        </div>
      <?php endwhile; else : ?>
        <p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
      <?php endif; ?>
      </div>
    </section>

<!--     <section>
      <div class="wrapper">
        <img src="images/dog.jpg" alt="A black dog smiling into the camera">
        <p class="caption">Photo by Tucker Good on Unsplash</p>
        <p>Walkies is an app for dog lovers of all kinds. If you own a dog, you can find someone to walk it. If you don't own a dog, you can apply to be a dog walker and meet and play with all kinds of dogs!</p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
      </div>
    </section>

    <h1>ABOUT PAGE</h1>
    <section>
      <div class="wrapper">
        <h1>How it works</h1>
        <h3>For Dog Owners</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
        <h3>For Dog Walkers</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
        </p>
      </div>
    </section> -->
<?php get_footer(); ?>

