I've split up the CSS into general styles+display for desktop, and responsive+display for tablet and mobile. The general styles are  in style.css, and the responsive styles are in responsive.css.

Note that I link to both css files in index.html. I must be careful to link responsive.css _after_ style.css because I've defined my media queries to override certain styles in style.css. (Try switching the order that the css files are linked and see what happens when you resize the viewport.)
