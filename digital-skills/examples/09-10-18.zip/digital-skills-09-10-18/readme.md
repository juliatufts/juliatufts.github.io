index.html
I've cleaned up my website a bit and added a bunch of new things such as:
- Google Fonts
- text properties (text-align, text-decoration, etc.)
- Icon Fonts via Font Awesome

Bonus note:
During the Icon Fonts section, we noticed that an HTML element can have more than one class! For example, the Instagram Font Awesome element has the following HTML:

<i class="fab fa-instagram"></i>

The class="fab fa-instagram" bit means that it belongs to both the "fab" class and the "fa-instagram" class. Note that the two names are separated by spaces.

If I want to target just the Instagram font icon, I can use the following CSS:

.fab.fa-instagram {
  /* CSS code here */
}

This targets all elements that belong to both the "fab" class and the "fa-instagram" class. Note that there is no space between .fab and .fa-instagram here.
