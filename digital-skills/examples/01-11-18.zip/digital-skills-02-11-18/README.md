I've split up the CSS into style.css and form-style.css, so you need to only look at form-style.css to see what styles are being applied to the form.
