errors-fixed.html
The errors exercise file fixed, with comment notes pointing out what the errors were.

example-part1.html
An example of some basic HTML.
http://ladieslearningcode.github.io/llc-digital-skills/module1-1.html#exercise-adding-content-part-1

example-part2.html
Adding more HTML - images, emphasis, and bold.
http://ladieslearningcode.github.io/llc-digital-skills/module1-1.html#exercise-adding-content-part-2

example-nav.html
Adding a nav with links.
http://ladieslearningcode.github.io/llc-digital-skills/module1-1.html#exercise-our-first-nav

example-css.html
Adding CSS and class attributes.
http://ladieslearningcode.github.io/llc-digital-skills/module1-2.html#class-exercise
